// fake empty header file to make Arduino IDE happy
