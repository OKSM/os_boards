#pragma once
#include "../../../ArduinoCore-API/api/HardwareSPI.h"
