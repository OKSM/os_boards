#pragma once
#include "../../../ArduinoCore-API/api/Client.h"
